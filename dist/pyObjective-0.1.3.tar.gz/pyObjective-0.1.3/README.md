# pyObjective

This is a simple package where you can optimize a complicated structure by simply creating the variables as you go, and passing the object to scipy.optimize when necessary.

As such, it removes the need to form a careful optimization function or to worry about which index of the vector refers to which variable. All of these details are abstracted away.

Let me know if you find it useful!
