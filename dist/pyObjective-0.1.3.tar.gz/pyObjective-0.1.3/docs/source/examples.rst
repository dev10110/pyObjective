Examples
***********


Rosenbrock Function
====================

We can optimize the Rosenbrock function by building it sequentially.

.. literalinclude:: examples/rosenbrock.py


Example using classes
========================

The user can also define classes and use them instead.

.. literalinclude:: examples/complex.py

