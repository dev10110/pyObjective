Module Reference
================

.. autoclass:: pyObjective.Variable
    :members:
    :private-members:
    :special-members:
    :exclude-members: __weakref__
    :member-order: bysource


.. autoclass:: pyObjective.Model
    :members:
    :private-members:
    :special-members:
    :exclude-members: __weakref__
    :member-order: bysource